/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Business.PeliculaBusiness;
import Data.CirculeDoubleListAction;
import Data.CirculeDoubleListChildish;
import Domain.Pelicula;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Heller
 */
public class CargarLista extends JInternalFrame implements ActionListener {

    private JButton jbtnFiccion;
    private JButton jbtnRomance;
    private JButton jbtnAccion;
    private JButton jbtnInfantil;
    private JButton jbtnDrama;
    private JButton jbtnComedia;
    private JLabel jlblGeneros;
    private JTextArea jtaAreaGeneros;

    public CargarLista() {
        super();
        //this.setSize(800,600);
        this.setPreferredSize(new Dimension(400, 400));
        init();
    }//constructor

    private void init() {

        this.setBounds(0, 0, 800, 600);
        this.setLayout(null);

        jtaAreaGeneros = new JTextArea();
        jtaAreaGeneros.setBounds(0, 0, 400, 400);

        this.jbtnAccion = new JButton("Action");
        this.jbtnAccion.setBounds(20, 150, 80, 20);
        this.jbtnAccion.addActionListener(this);
        this.add(this.jbtnAccion);

        this.jbtnComedia = new JButton("Comedy");
        this.jbtnComedia.addActionListener(this);
        this.jbtnComedia.setBounds(300, 150, 80, 20);
        this.add(this.jbtnComedia);

        this.jbtnDrama = new JButton("Drama");
        this.jbtnDrama.addActionListener(this);
        this.jbtnDrama.setBounds(250, 200, 80, 20);
        this.add(this.jbtnDrama);

        this.jbtnFiccion = new JButton("Fiction");
        this.jbtnFiccion.addActionListener(this);
        this.jbtnFiccion.setBounds(30, 200, 100, 20);
        this.add(this.jbtnFiccion);

        this.jbtnRomance = new JButton("Romance");
        this.jbtnRomance.addActionListener(this);
        this.jbtnRomance.setBounds(125, 240, 120, 20);
        this.add(this.jbtnRomance);

        this.jlblGeneros = new JLabel("Generos");
        this.jlblGeneros.setBounds(165, 0, 80, 20);
        this.add(this.jlblGeneros);

    } //init

    @Override
    public void actionPerformed(ActionEvent e) {
        PeliculaBusiness pb = new PeliculaBusiness();
        CirculeDoubleListAction lA = new CirculeDoubleListAction();
        CirculeDoubleListChildish lCh = new CirculeDoubleListChildish();
        if (e.getSource() == jbtnAccion) {
            try {
                pb.fileReader();
//            Pelicula dato=new Pelicula(10, "title", 2, 5, 7, 1);
//            lA.agregarAlInicio(dato);
                add(jtaAreaGeneros);
                JOptionPane.showMessageDialog(null, lA.printListC());
            } catch (IOException ex) {
                Logger.getLogger(CargarLista.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
