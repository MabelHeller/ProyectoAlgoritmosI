/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Domain.Nodo;
import Domain.Pelicula;
import javax.swing.JOptionPane;

/**
 *
 * @author Heller
 */
public class CirculeDoubleListPeliculas {

    private Nodo headNode;
    private Nodo tailNode;

    public CirculeDoubleListPeliculas(Nodo headNode, Nodo tailNode) {
        this.headNode = headNode;
        this.tailNode = tailNode;
    }

    public CirculeDoubleListPeliculas() {
        this.headNode = headNode;
        this.tailNode = tailNode;
    }

    public void Lista() {
        headNode = null;
        tailNode = null;
    }

    public void agregarAlInicio(Pelicula dato) {
        Nodo newPtr = new Nodo();
        Nodo tempPtr = new Nodo();
        newPtr.setDato(dato);
        if (headNode == null) {
            headNode = newPtr;
            tailNode = newPtr;
            headNode.setNext(tailNode);
            tailNode.setPreviousPtr(headNode);
        } else {
            newPtr.setNext(headNode);
            headNode = newPtr;
            headNode.setPreviousPtr(tailNode);
            tailNode.setNext(headNode);
            tailNode.setPreviousPtr(tempPtr.getNext());
        }
    }

    public boolean buscar(String dato) {
        Pelicula p = new Pelicula();
        boolean encontrado = false;
        Nodo tempPtr = headNode;
        // Recorre la lista hasta encontrar el elemento o hasta 
        // llega al primer nodo nuevamente.
        do {
            if (tempPtr.getDato().getTitle().equals(dato)) {
                encontrado = true;
                JOptionPane.showMessageDialog(null, tempPtr.getDato());
                return true;

            } else {
                tempPtr = tempPtr.getNext();
            }
        } while (tempPtr != headNode && encontrado != true);

        return false;
    }

    public void printListC() {
        boolean f = true;
        Nodo tempPtr = headNode;
        if (headNode == null) {
            System.out.print(("The list is empty."));
        } else {
            while (f) {
                System.out.print(tempPtr.getDato().toString() + " ->  ");
                if (tempPtr == tailNode) {
                    f = false;
                }
                tempPtr = tempPtr.getNext();
            }
        }
    }
}
