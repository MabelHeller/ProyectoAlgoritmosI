/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Domain.Nodo;
import Domain.Pelicula;

/**
 *
 * @author Heller
 */
public class CirculeDoubleListDrama {
  private Nodo headNode;
    private Nodo tailNode;

    public CirculeDoubleListDrama(Nodo headNode, Nodo tailNode) {
        this.headNode = headNode;
        this.tailNode = tailNode;
    }

    public CirculeDoubleListDrama() {
        this.headNode = headNode;
        this.tailNode = tailNode;
    }

    public void Lista() {
        headNode = null;
        tailNode = null;
    }

    public void agregarAlInicio(Pelicula dato) {
        Nodo newPtr = new Nodo();
        Nodo tempPtr = new Nodo();
        newPtr.setDato(dato);
        if (headNode == null) {
            headNode = newPtr;
            tailNode = newPtr;
            headNode.setNext(tailNode);
            tailNode.setPreviousPtr(headNode);
        } else {
            newPtr.setNext(headNode);
            headNode = newPtr;
            headNode.setPreviousPtr(tailNode);
            tailNode.setNext(headNode);
            tailNode.setPreviousPtr(tempPtr.getNext());
        }
    }

//    public boolean buscar(Pelicula dato) {
//         Nodo tempPtr=headNode;
//         while((tempPtr.getNext()!=headNode) && (!(tempPtr.getDato().equals(dato))))
//                   tempPtr=tempPtr.getNext();
//         return tempPtr.getDato().equals(dato);
//       }
//         

    public void printListC() {
        boolean f = true;
        Nodo tempPtr = headNode;
        if (headNode == null) {
            System.out.print(("The list is empty."));
        } else {
            while (f) {
                System.out.print(tempPtr.getDato().toString() + " ->  ");
                if (tempPtr == tailNode) {
                    f = false;
                }
                tempPtr = tempPtr.getNext();
            }
        }
    }

    public void insertOrder(Pelicula p) {
        Nodo newPtr = new Nodo();
        Nodo tempPtr = new Nodo();
        newPtr.setDato(p);
        tempPtr = headNode;
        while (tempPtr != null && tempPtr.getDato().getTitle().compareTo(newPtr.getDato().getTitle()) < 0) {
            if (tempPtr == tailNode) {
                break;
            }//if para saber si llego al final de la lista
            tempPtr = tempPtr.getNext();
        }//while para recorrer la lista
        //preguntar porque se detuvo
        if (newPtr.getSize() == 0) {
            headNode=newPtr;
            tailNode=newPtr;
            tailNode.setNext(headNode);
            headNode.setPreviousPtr(tailNode);
        } else {       
            if (tempPtr == headNode) {
                if (tempPtr.getDato().getTitle().compareTo(newPtr.getDato().getTitle()) > 0) {
                    newPtr.setNext(headNode);
                    newPtr.setPreviousPtr(tailNode);
                    headNode.setPreviousPtr(newPtr);
                    headNode=newPtr;
                    tailNode.setNext(headNode);
                    headNode.setPreviousPtr(tailNode);
                } else {
                    newPtr.setPreviousPtr(headNode);
                    newPtr.setNext(tailNode);
                    headNode.setNext(newPtr);
                    tailNode=newPtr;
                    tailNode.setNext(headNode);
                    headNode.setPreviousPtr(tailNode);
                }//if si el nuevo nodo va antes o despues de head
            } else {
                if (tempPtr == tailNode && tempPtr.getDato().getTitle().compareTo(newPtr.getDato().getTitle()) < 0) {
                    newPtr.setPreviousPtr(tailNode);
                    newPtr.setNext(headNode);
                    tailNode.setNext(newPtr);
                    tailNode=newPtr;
                    headNode.setPreviousPtr(tailNode);
                    tailNode.setNext(headNode);
                } else {
                    tempPtr.getPreviousPtr().setNext(newPtr);
                    newPtr.setPreviousPtr(tempPtr.getPreviousPtr());
                    newPtr.setNext(tempPtr);
                    tempPtr.setPreviousPtr(newPtr);
                }//if para saber si el nuevo nodo va despues de tail o esta en medio de la lista
            }//if el en que posicion va el nuevo nodo
        }//if la lista esta llena o no
        newPtr.setSize(newPtr.getSize() + 1);
    }


}
