/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Domain.Nodo;
import Domain.Pelicula;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.csvreader.CsvWriter;
import com.csvreader.CsvReader;
import java.io.File;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Heller
 */
public class PeliculaData {

    private Nodo headNode;

    public List<Pelicula> fileReader() throws FileNotFoundException, IOException {
        CirculeDoubleListAction lAction = new CirculeDoubleListAction();
        CirculeDoubleListChildish lChildish = new CirculeDoubleListChildish();
        CirculeDoubleListComedy lComedy = new CirculeDoubleListComedy();
        CirculeDoubleListFiction lFiction = new CirculeDoubleListFiction();
        CirculeDoubleListRomance lRomance = new CirculeDoubleListRomance();
        CirculeDoubleListDrama lDrama = new CirculeDoubleListDrama();
        CirculeDoubleListPeliculas lP = new CirculeDoubleListPeliculas();
        List<Pelicula> listaPeli = new ArrayList<Pelicula>();

        boolean b = false;
        String linea;
        CsvReader br = new CsvReader("datos.csv");
        br.readHeaders();
        while (br.readRecord()) {

            Pelicula pelicula = new Pelicula();
            pelicula.setCode(Integer.parseInt(br.get(0)));
            pelicula.setTitle(br.get(1));
            pelicula.setGender(Integer.parseInt(br.get(2)));
            pelicula.setTotal(Integer.parseInt(br.get(3)));
            pelicula.setSubtitled(Integer.parseInt(br.get(4)));
            pelicula.setPremier(Integer.parseInt(br.get(5)));
            listaPeli.add(pelicula);
//            lP.agregarAlInicio(pelicula);
//            lP.printListC();
            switch (pelicula.getGender()) {
                case 1000:
                    lDrama.agregarAlInicio(pelicula);
                    //lDrama.printListC();
                    break;
                case 2000:
                    lComedy.agregarAlInicio(pelicula);
                    //lComedy.printListC();
                    break;
                case 3000:
                    lChildish.agregarAlInicio(pelicula);
                    break;
                case 4000:
                    lAction.agregarAlInicio(pelicula);
                    break;
                case 5000:
                    lRomance.agregarAlInicio(pelicula);
                    break;
                case 6000:
                    lFiction.agregarAlInicio(pelicula);
                    break;
                default:
                    break;
            }
//
        }
        br.close();
        for (int i = 0; i < listaPeli.size(); i++) {
            lP.agregarAlInicio(listaPeli.get(i));
//            lP.printListC();
        }  
        return listaPeli;
    }

    public boolean writerFile(Pelicula pelicula) throws IOException {
        File file = new File("datos.csv");
        if (file.exists()) {
            File filePeli = new File("datos.csv");
        }
        CsvWriter cw = new CsvWriter(new FileWriter(file, true), ',');
        cw.write(Integer.toString(pelicula.getCode()));
        cw.write(pelicula.getTitle());
        cw.write(Integer.toString(pelicula.getGender()));
        cw.write(Integer.toString(pelicula.getTotal()));
        cw.write(Integer.toString(pelicula.getSubtitled()));
        cw.write(Integer.toString(pelicula.getPremier()));
        cw.endRecord();
        cw.close();
        return true;
    }

    public boolean buscarPeli(String titulo) {
        File file = new File("datos.csv");
        List<Pelicula> listaPeliculas = new ArrayList<Pelicula>();
        if (file.exists()) {
           
            try {
                CsvReader br = new CsvReader("datos.csv");
                br.readHeaders();
                while (br.readRecord()) {
                    Pelicula pelicula = new Pelicula();
                    pelicula.setCode(Integer.parseInt(br.get(0)));
                    pelicula.setTitle(br.get(1));
                    pelicula.setGender(Integer.parseInt(br.get(2)));
                    pelicula.setTotal(Integer.parseInt(br.get(3)));
                    pelicula.setSubtitled(Integer.parseInt(br.get(4)));
                    pelicula.setPremier(Integer.parseInt(br.get(5)));
                    listaPeliculas.add(pelicula);
                }
            } catch (FileNotFoundException ex) {
                Logger.getLogger(PeliculaData.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(PeliculaData.class.getName()).log(Level.SEVERE, null, ex);
            }
            
                Pelicula pelicula = null;
                for (int i = 0; i < listaPeliculas.size(); i++) {
                    if (listaPeliculas.get(i).getTitle().equalsIgnoreCase(titulo)) {
                        pelicula = listaPeliculas.get(i);
                        JOptionPane.showMessageDialog(null, pelicula);
                        return true;
                    }
                    
                }
           
        }
        return false;
    }

    public List<Pelicula> listadoOrden() {
        List<Pelicula> listaPeli = new ArrayList<Pelicula>();
        try {

            boolean b = false;
            String linea;
            CsvReader br = new CsvReader("datos.csv");
            br.readHeaders();
            while (br.readRecord()) {
                Pelicula pelicula = new Pelicula();
                pelicula.setCode(Integer.parseInt(br.get(0)));
                pelicula.setTitle(br.get(1));
                pelicula.setGender(Integer.parseInt(br.get(2)));
                pelicula.setTotal(Integer.parseInt(br.get(3)));
                pelicula.setSubtitled(Integer.parseInt(br.get(4)));
                pelicula.setPremier(Integer.parseInt(br.get(5)));

            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PeliculaData.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(PeliculaData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaPeli;
    }

//    public boolean buscar(String nombre) {
//        Pelicula p = new Pelicula();
//        boolean encontrado = false;
//        CirculeDoubleListAction c = new CirculeDoubleListAction();
//
//        Nodo tempPtr = headNode;
//        // Recorre la lista hasta encontrar el elemento o hasta 
//        // llega al primer nodo nuevamente.
//        do {
//            if (tempPtr.getDato().getTitle().equals(nombre)) {
//                encontrado = true;
//                JOptionPane.showMessageDialog(null, tempPtr.getDato());
//                return true;
//
//            } else {
//                tempPtr = tempPtr.getNext();
//            }
//        } while (tempPtr != headNode && encontrado != true);
//
//        return false;
//    }
}
