/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoalgoritmos;

import Business.PeliculaBusiness;
import Data.CirculeDoubleListDrama;
import Data.CirculeDoubleListPeliculas;
import Data.PeliculaData;
import Domain.Pelicula;
import GUI.Ventana;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;

/**
 *
 * @author Heller
 */
public class ProyectoAlgoritmos {

    public static void main(String[] args) throws IOException, IOException {
        PeliculaBusiness p = new PeliculaBusiness();
        PeliculaData pd = new PeliculaData();
        CirculeDoubleListPeliculas listaCircular = new CirculeDoubleListPeliculas();
        CirculeDoubleListDrama d = new CirculeDoubleListDrama();
        //p.buscarPeli("No");
//        List<Pelicula> lista = new ArrayList<Pelicula>();
//        lista = pd.fileReader();
//        for (int i = 0; i < lista.size(); i++) {
//            System.out.println(lista.get(i).toString()); 
//        }  
//        listaCircular.printListC();
//        System.out.println(listaCircular.buscar("Nirvana"));
//        
//        Pelicula pe100 = new Pelicula(12, "heller", 20, 30, 1, 2);
//        Pelicula pe = new Pelicula(12, "heller", 20, 30, 1, 2);
//        //p.writerFile(pe);
//        Pelicula pe1000 = new Pelicula(14, "Mabel", 30, 40, 2, 3);
//        Pelicula pe1 = new Pelicula(11, "Mabel", 30, 40, 2, 3);
//        Pelicula pe2 = new Pelicula(10, "Ar", 30, 40, 2, 3);
//        Pelicula pe3 = new Pelicula(9, "amor", 1000, 40, 2, 3);
//        Pelicula pe4 = new Pelicula(8, "A Time to Killer", 1000, 30, 0, 1);
//
//        Pelicula pe5 = new Pelicula(7, "Airplane", 2000, 25, 0, 0);
//
//        Pelicula pe6 = new Pelicula(6, "Aladdin", 3000, 20, 0, 0);
//        Pelicula pe9 = new Pelicula(4, "Amistad", 1000, 50, 0, 1);
//        Pelicula pe7 = new Pelicula(5, "Antz", 3000, 40, 0, 0);
//        Pelicula pe8 = new Pelicula(3, "Armageddon", 4000, 25, 1, 1);
//        Pelicula pe10 = new Pelicula(2, "Austin Powers", 2000, 30, 0, 0);
//        Pelicula pe11 = new Pelicula(1, "Child's Play", 6000, 35, 1, 0);
//
//////        p.writerFile(pe1);
////        lista = new ArrayList<Pelicula>();
//        //lista = 
//        //d.printListC();
////        for (int i = 0; i < lista.size(); i++) {
////            System.out.println(lista.get(i).toString()); 
////        }
//        listaCircular.agregarAlInicio(pe1000);
//        listaCircular.agregarAlInicio(pe1);
//        listaCircular.agregarAlInicio(pe2);
//        listaCircular.agregarAlInicio(pe3);
//        listaCircular.agregarAlInicio(pe4);
//        listaCircular.agregarAlInicio(pe5);
//        listaCircular.agregarAlInicio(pe6);
//        listaCircular.agregarAlInicio(pe7);
//
//        listaCircular.agregarAlInicio(pe8);
//        listaCircular.agregarAlInicio(pe9);
//        listaCircular.agregarAlInicio(pe10);
//        listaCircular.agregarAlInicio(pe11);
//        listaCircular.agregarAlInicio(pe100);
//        listaCircular.printListC();


//        System.out.println();
//       listaCircular.agregarAlInicio(pe);
        //listaCircular.printListC();
//       System.out.println(listaCircular.buscar("he"));
//        listaCircular.insertOrder(pe2);
//        listaCircular.printListC();
        Ventana principal = new Ventana();
        principal.setVisible(true);
        principal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
